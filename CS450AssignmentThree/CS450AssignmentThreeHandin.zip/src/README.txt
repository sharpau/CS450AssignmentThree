CS450/550 Assignment 3
Members: Austin Sharp, Padraic McGraw

USAGE: CS450AssignmentThree PROJECTION_TYPE LEFT RIGHT BOTTOM TOP NEAR FAR
		PROJECT_TYPE either "O" or "P" standing for orthographic and perspective repsectively.
		LEFT clipping volume coord
		RIGHT clipping volume coord
		BOTTOM clipping volume coord
		TOP clipping volume coord
		NEAR clipping volume coord
		FAR clipping volume coord